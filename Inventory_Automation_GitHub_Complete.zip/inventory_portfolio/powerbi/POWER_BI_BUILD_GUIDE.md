# Build the Power BI report

1. Power BI Desktop → **Get data → Text/CSV** → `data/inventory_dashboard.csv` → **Transform Data**.
2. Name the query **Inventory**. Set `quantity`, `reorder_point`, `suggested_order_qty` to whole number; `unit_cost`, `inventory_value`, `reorder_cost` to decimal; `alert_required`, `alert_sent`, `has_data_issue` to True/False; `last_checked`, `last_alerted` to Date/Time (empty last_alerted values become null). Close & Apply.
3. Add the measures in `Inventory_Measures.dax` individually via **Modeling → New measure**. Format `Reorder Rate` as %, inventory and reorder costs as currency.
4. Add **Cards**: Total Products, Low Stock Products, Out of Stock Products, Total Inventory Value, Estimated Reorder Cost, Pending Alerts.
5. Add **Donut chart**: Legend `stock_status`, Values distinct count of `product_id`.
6. Add **Clustered bar chart**: Y `inventory_group`, X `Products Needing Reorder` (or distinct count of product_id, with status filter Low/Out).
7. Add **Clustered column chart**: X `inventory_group`, Y `Total Inventory Value`.
8. Add **Table**: product_name, inventory_group, quantity, reorder_point, stock_status, suggested_order_qty, reorder_cost, alert_sent, last_alerted. Filter to Low Stock and Out of Stock, sort by stock_status or reorder_cost.
9. Add slicers: `inventory_group`, `stock_status`, `alert_sent`.
10. Set conditional formatting for stock_status; check that the source snapshot produces **50 products, 33 in stock, 11 low, 6 out, $46,779.40 inventory value, $14,204.05 reorder cost**.
11. Save as `Inventory_Monitoring.pbix` and export a screenshot to `assets/`. **This bundle does not contain a .pbix file**; it includes a working browser dashboard and a Power BI build guide.

**Refresh note:** The PDF is a static snapshot. To refresh the Power BI report, export an updated CSV from your Python/Google Sheets pipeline with the same schema and refresh Power BI Desktop. This is not an automatically refreshed Power BI service dataset.
