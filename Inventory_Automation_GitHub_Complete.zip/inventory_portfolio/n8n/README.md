# n8n workflow

Import `Daily_Inventory_Monitor_SANITIZED.json`, configure your own Google Sheets and Gmail connections, spreadsheet ID, sheet, and alert recipient, and test before activation. The schedule is configured for 8 AM in the workflow timezone; verify your n8n instance timezone. The exported workflow is inactive.

**Privacy:** Account identifiers and original destination email have been replaced with placeholders. Do not commit your live export without sanitizing it.
